import '#template/js/admin'
